# ========================================
# VISUALIZATION HELPER FUNCTIONS FOR MONTE CARLO
# ========================================

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.colors import LinearSegmentedColormap
from IPython.display import display, clear_output
import time


def update_mc_value_function_plot(V, title="Monte Carlo Value Function", episode=0, highlight_state=None):
    """
    Update persistent value function plot for FrozenLake 4x4 environment.
    Similar to DP visualization but adapted for Monte Carlo method.
    
    Args:
        V: Value function array (16 states for FrozenLake 4x4)
        title: Plot title
        episode: Current episode number
        highlight_state: State to highlight with red border
    """
    clear_output(wait=True)
    
    fig = plt.figure(figsize=(10, 8))
    
    # FrozenLake 4x4 grid
    grid_size = (4, 4)
    
    # Reshape values to grid
    value_grid = V.reshape(grid_size)
    
    # Create colormap from blue (low) to red (high)
    cmap = LinearSegmentedColormap.from_list("custom", ["lightblue", "lightgreen", "yellow", "red"])
    
    # Normalize values for coloring
    vmin, vmax = V.min(), V.max()
    if vmax == vmin:
        vmax = vmin + 1e-6
    
    ax = plt.gca()
    
    # FrozenLake layout: S=Start, F=Frozen, H=Hole, G=Goal
    # Standard FrozenLake-v1 4x4 layout
    frozen_lake_layout = [
        ['S', 'F', 'F', 'F'],
        ['F', 'H', 'F', 'H'], 
        ['F', 'F', 'F', 'H'],
        ['H', 'F', 'F', 'G']
    ]
    
    for i in range(grid_size[0]):
        for j in range(grid_size[1]):
            s = i * grid_size[1] + j
            value = value_grid[i, j]
            color_intensity = (value - vmin) / (vmax - vmin)
            color = cmap(color_intensity)
            
            # Special coloring for holes and goal
            if frozen_lake_layout[i][j] == 'H':
                color = 'black'  # Holes are black
            elif frozen_lake_layout[i][j] == 'G':
                color = 'gold'   # Goal is gold
                
            # Highlight specific state if requested
            if s == highlight_state:
                edgecolor = 'red'
                linewidth = 4
            else:
                edgecolor = 'black'
                linewidth = 2
            
            # Draw cell
            rect = patches.Rectangle((j, grid_size[0]-1-i), 1, 1, 
                                   linewidth=linewidth, edgecolor=edgecolor, facecolor=color)
            ax.add_patch(rect)
            
            # Add value text (skip for holes)
            if frozen_lake_layout[i][j] != 'H':
                ax.text(j + 0.5, grid_size[0]-1-i + 0.5, f'{value:.3f}', 
                       ha='center', va='center', fontsize=10, fontweight='bold')
            
            # Add state type labels
            cell_type = frozen_lake_layout[i][j]
            if cell_type == 'S':
                ax.text(j + 0.1, grid_size[0]-1-i + 0.9, 'S', fontsize=16, fontweight='bold', color='blue')
            elif cell_type == 'H':
                ax.text(j + 0.5, grid_size[0]-1-i + 0.5, 'H', fontsize=16, fontweight='bold', color='red')
            elif cell_type == 'G':
                ax.text(j + 0.9, grid_size[0]-1-i + 0.1, 'G', fontsize=16, fontweight='bold', color='darkgreen')
    
    # Add state number labels
    for i in range(grid_size[0]):
        for j in range(grid_size[1]):
            s = i * grid_size[1] + j
            ax.text(j + 0.05, grid_size[0]-1-i + 0.05, f's{s}', fontsize=8, color='gray')
    
    ax.set_xlim(0, grid_size[1])
    ax.set_ylim(0, grid_size[0])
    ax.set_aspect('equal')
    ax.set_title(f'{title} (Episode {episode})', fontsize=14, fontweight='bold')
    ax.set_xticks(range(grid_size[1] + 1))
    ax.set_yticks(range(grid_size[0] + 1))
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    
    # Add grid lines
    for i in range(grid_size[1] + 1):
        ax.axvline(i, color='gray', linewidth=0.5, alpha=0.7)
    for i in range(grid_size[0] + 1):
        ax.axhline(i, color='gray', linewidth=0.5, alpha=0.7)
    
    # Add legend
    legend_text = ("FrozenLake 4x4: S=Start(0), F=Frozen, H=Hole, G=Goal(15)\n"
                  f"Values range: [{vmin:.3f}, {vmax:.3f}]")
    ax.text(0.5, -0.15, legend_text, transform=ax.transAxes, ha='center', 
            fontsize=10, bbox=dict(boxstyle="round,pad=0.3", facecolor='lightgray', alpha=0.8))
    
    plt.tight_layout()
    display(fig)
    plt.close()


def update_mc_control_plot(Q, episode, status=""):
    """Update Q-function visualization with arrows showing actions and Q-values for FrozenLake 4x4"""
    clear_output(wait=True)
    
    fig = plt.figure(figsize=(10, 8))
    
    # Action directions: 0=Left, 1=Down, 2=Right, 3=Up
    action_directions = [(-0.3, 0), (0, -0.3), (0.3, 0), (0, 0.3)]  # dx, dy for arrows
    action_symbols = ['←', '↓', '→', '↑']
    
    # Find Q-value range for legend display
    q_min, q_max = Q.min(), Q.max()
    if q_max == q_min:
        q_max = q_min + 1e-6
    
    for i in range(4):
        for j in range(4):
            s = i * 4 + j
            
            # Draw cell background
            rect = patches.Rectangle((j, 3-i), 1, 1, linewidth=2, edgecolor='black', 
                                   facecolor='lightgray', alpha=0.2)
            plt.gca().add_patch(rect)
            
            # Add state number
            plt.text(j + 0.05, 3-i + 0.95, f's{s}', fontsize=8, color='gray', fontweight='bold')
            
            # Mark special states
            if s == 0:  # Start
                plt.text(j + 0.95, 3-i + 0.95, 'S', fontsize=12, fontweight='bold', color='blue')
            elif s == 15:  # Goal
                plt.text(j + 0.95, 3-i + 0.95, 'G', fontsize=12, fontweight='bold', color='green')
                continue  # Skip arrows for goal state
            elif s in [5, 7, 11, 12]:  # Holes
                plt.text(j + 0.5, 3-i + 0.5, 'H', fontsize=20, fontweight='bold', color='red')
                continue  # Skip arrows for hole states
            
            # Draw arrows for each action with Q-values
            center_x = j + 0.5
            center_y = 3-i + 0.5
            
            # Find the action with highest Q-value for this state
            q_values_state = Q[s, :]
            max_q_value = np.max(q_values_state)
            best_action = np.argmax(q_values_state) if max_q_value > 0 else -1
            
            for a in range(4):  # 4 actions
                q_value = Q[s, a]
                
                # Use uniform color for all arrows, except highlight the best one
                if a == best_action and max_q_value > 0:
                    color = 'red'  # Highlight color for highest Q-value
                    linewidth = 3  # Thicker arrow
                    mutation_scale = 18
                else:
                    color = 'darkblue'  # Uniform color for all other arrows
                    linewidth = 2
                    mutation_scale = 15
                
                # Calculate arrow position
                dx, dy = action_directions[a]
                
                # Offset arrows slightly from center to avoid overlap
                offset_factor = 0.15
                if a == 0:  # Left
                    start_x, start_y = center_x - offset_factor, center_y + offset_factor
                elif a == 1:  # Down
                    start_x, start_y = center_x + offset_factor, center_y - offset_factor
                elif a == 2:  # Right
                    start_x, start_y = center_x + offset_factor, center_y - offset_factor
                else:  # Up
                    start_x, start_y = center_x - offset_factor, center_y + offset_factor
                
                # Draw arrow
                arrow = patches.FancyArrowPatch((start_x, start_y), 
                                              (start_x + dx, start_y + dy),
                                              arrowstyle='->', 
                                              mutation_scale=mutation_scale,
                                              color=color,
                                              linewidth=linewidth)
                plt.gca().add_patch(arrow)
                
                # Add Q-value label near arrow
                # Adjust label position to avoid overlap
                if a == 0:  # Left
                    label_x, label_y = j + 0.15, center_y + 0.25
                elif a == 1:  # Down
                    label_x, label_y = center_x + 0.25, 3-i + 0.15
                elif a == 2:  # Right
                    label_x, label_y = j + 0.85, center_y - 0.25
                else:  # Up
                    label_x, label_y = center_x - 0.25, 3-i + 0.85
                
                # Add Q-value text with background for readability
                plt.text(label_x, label_y, f'{q_value:.2f}', 
                         ha='center', va='center', fontsize=7, fontweight='bold',
                         bbox=dict(boxstyle="round,pad=0.1", facecolor='white', alpha=0.8))
    
    # Set plot properties
    plt.xlim(0, 4)
    plt.ylim(0, 4)
    plt.gca().set_aspect('equal')
    plt.title(f'Q-Function with Actions - Episode {episode} {status}', 
              fontsize=14, fontweight='bold')
    plt.xticks([])
    plt.yticks([])
    
    # Add grid lines
    for i in range(5):
        plt.axhline(i, color='gray', linewidth=0.5, alpha=0.5)
        plt.axvline(i, color='gray', linewidth=0.5, alpha=0.5)
    
    # Add legend
    legend_text = (f"Actions: {action_symbols[0]}=Left, {action_symbols[1]}=Down, "
                  f"{action_symbols[2]}=Right, {action_symbols[3]}=Up\n"
                  f"Q-values: [{q_min:.2f}, {q_max:.2f}] | "
                  f"Red thick arrows = Highest Q-value (if > 0)")
    plt.figtext(0.5, 0.02, legend_text, ha='center',
                fontsize=9, bbox=dict(boxstyle="round,pad=0.3", facecolor='lightblue', alpha=0.8))
    
    plt.tight_layout()
    display(fig)
    plt.close()
