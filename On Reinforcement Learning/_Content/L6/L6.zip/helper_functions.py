"""
Helper functions for TD Learning lecture
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.colors import LinearSegmentedColormap
from IPython.display import display, clear_output
import time


def update_value_function_plot(V, title="TD Value Function", episode=0, highlight_state=None):
    """
    Update persistent value function plot for FrozenLake 4x4 environment.
    Matches the visualization style from Monte Carlo lecture exactly.
    
    Args:
        V: Value function array (16 states for FrozenLake 4x4)
        title: Plot title
        episode: Current episode number
        highlight_state: State to highlight with red border
    """
    clear_output(wait=True)
    
    fig, ax = plt.subplots(figsize=(10, 8))
    
    # FrozenLake 4x4 grid
    grid_size = (4, 4)
    
    # Reshape values to grid
    value_grid = V.reshape(grid_size)
    
    # Create colormap from blue (low) to red (high)
    cmap = LinearSegmentedColormap.from_list("custom", ["lightblue", "lightgreen", "yellow", "red"])
    
    # Normalize values for coloring
    vmin, vmax = V.min(), V.max()
    if vmax == vmin:
        vmax = vmin + 1e-6
    
    ax = plt.gca()
    
    # FrozenLake layout: S=Start, F=Frozen, H=Hole, G=Goal
    # Standard FrozenLake-v1 4x4 layout
    frozen_lake_layout = [
        ['S', 'F', 'F', 'F'],
        ['F', 'H', 'F', 'H'], 
        ['F', 'F', 'F', 'H'],
        ['H', 'F', 'F', 'G']
    ]
    
    for i in range(grid_size[0]):
        for j in range(grid_size[1]):
            s = i * grid_size[1] + j
            value = value_grid[i, j]
            color_intensity = (value - vmin) / (vmax - vmin)
            color = cmap(color_intensity)
            
            # Special coloring for holes and goal
            if frozen_lake_layout[i][j] == 'H':
                color = 'black'  # Holes are black
            elif frozen_lake_layout[i][j] == 'G':
                color = 'gold'   # Goal is gold
                
            # Highlight specific state if requested
            if s == highlight_state:
                edgecolor = 'red'
                linewidth = 4
            else:
                edgecolor = 'black'
                linewidth = 2
            
            # Draw cell
            rect = patches.Rectangle((j, grid_size[0]-1-i), 1, 1, 
                                   linewidth=linewidth, edgecolor=edgecolor, facecolor=color)
            ax.add_patch(rect)
            
            # Add value text (skip for holes)
            if frozen_lake_layout[i][j] != 'H':
                ax.text(j + 0.5, grid_size[0]-1-i + 0.5, f'{value:.3f}', 
                       ha='center', va='center', fontsize=10, fontweight='bold')
            
            # Add state type labels
            cell_type = frozen_lake_layout[i][j]
            if cell_type == 'S':
                ax.text(j + 0.1, grid_size[0]-1-i + 0.9, 'S', fontsize=16, fontweight='bold', color='blue')
            elif cell_type == 'H':
                ax.text(j + 0.5, grid_size[0]-1-i + 0.5, 'H', fontsize=16, fontweight='bold', color='red')
            elif cell_type == 'G':
                ax.text(j + 0.9, grid_size[0]-1-i + 0.1, 'G', fontsize=16, fontweight='bold', color='darkgreen')
    
    # Add state number labels
    for i in range(grid_size[0]):
        for j in range(grid_size[1]):
            s = i * grid_size[1] + j
            ax.text(j + 0.05, grid_size[0]-1-i + 0.05, f's{s}', fontsize=8, color='gray')
    
    ax.set_xlim(0, grid_size[1])
    ax.set_ylim(0, grid_size[0])
    ax.set_aspect('equal')
    ax.set_title(f'{title} (Episode {episode})', fontsize=14, fontweight='bold')
    ax.set_xticks(range(grid_size[1] + 1))
    ax.set_yticks(range(grid_size[0] + 1))
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    
    # Add grid lines
    for i in range(grid_size[1] + 1):
        ax.axvline(i, color='gray', linewidth=0.5, alpha=0.7)
    for i in range(grid_size[0] + 1):
        ax.axhline(i, color='gray', linewidth=0.5, alpha=0.7)
    
    # Add legend
    legend_text = ("FrozenLake 4x4: S=Start(0), F=Frozen, H=Hole, G=Goal(15)\n"
                  f"Values range: [{vmin:.3f}, {vmax:.3f}]")
    ax.text(0.5, -0.15, legend_text, transform=ax.transAxes, ha='center', 
            fontsize=10, bbox=dict(boxstyle="round,pad=0.3", facecolor='lightgray', alpha=0.8))
    
    plt.tight_layout()
    display(fig)
    plt.close(fig)


def plot_learning_curves(stats, title="Learning Progress"):
    """
    Plot learning curves showing episode returns and lengths.
    
    Args:
        stats: Dictionary with 'episode_returns' and 'episode_lengths'
        title: Plot title
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # Plot episode returns
    axes[0].plot(stats['episode_returns'], alpha=0.6)
    axes[0].set_xlabel('Episode')
    axes[0].set_ylabel('Return')
    axes[0].set_title('Episode Returns')
    axes[0].grid(True, alpha=0.3)
    
    # Add moving average
    window = min(50, len(stats['episode_returns']) // 10)
    if window > 1:
        moving_avg = np.convolve(stats['episode_returns'], 
                                 np.ones(window)/window, mode='valid')
        axes[0].plot(range(window-1, len(stats['episode_returns'])), 
                    moving_avg, 'r-', linewidth=2, label=f'{window}-episode MA')
        axes[0].legend()
    
    # Plot episode lengths
    axes[1].plot(stats['episode_lengths'], alpha=0.6)
    axes[1].set_xlabel('Episode')
    axes[1].set_ylabel('Steps')
    axes[1].set_title('Episode Lengths')
    axes[1].grid(True, alpha=0.3)
    
    plt.suptitle(title, fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.show()


def render_episode(env, policy_fn, max_steps=100, sleep_time=0.5):
    """
    Render a single episode following the given policy.
    
    Args:
        env: Gymnasium environment (must have render_mode='human')
        policy_fn: Function that takes state and returns action
        max_steps: Maximum steps per episode
        sleep_time: Delay between steps (seconds)
    """
    state = env.reset()[0]
    done = False
    total_reward = 0
    steps = 0
    
    print(f"Starting episode from state {state}")
    
    while not done and steps < max_steps:
        action = policy_fn(state)
        next_state, reward, done, truncated, info = env.step(action)
        
        total_reward += reward
        steps += 1
        
        print(f"Step {steps}: State {state} -> Action {action} -> State {next_state}, Reward: {reward}")
        
        time.sleep(sleep_time)
        state = next_state
        
        if truncated:
            done = True
    
    print(f"\nEpisode finished after {steps} steps with total reward: {total_reward}")
    return total_reward, steps


def compare_value_functions(V1, V2, labels=("Method 1", "Method 2"), shape=(4, 4)):
    """
    Compare two value functions side by side.
    
    Args:
        V1, V2: Value function arrays
        labels: Labels for each method
        shape: Grid shape
    """
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    # Plot first value function
    grid1 = V1.reshape(shape)
    im1 = axes[0].imshow(grid1, cmap='viridis', interpolation='nearest')
    axes[0].set_title(labels[0], fontsize=12, fontweight='bold')
    plt.colorbar(im1, ax=axes[0])
    
    # Add values
    for i in range(shape[0]):
        for j in range(shape[1]):
            state = i * shape[1] + j
            axes[0].text(j, i, f'{V1[state]:.3f}',
                        ha="center", va="center", color="w", fontsize=9)
    
    # Plot second value function
    grid2 = V2.reshape(shape)
    im2 = axes[1].imshow(grid2, cmap='viridis', interpolation='nearest')
    axes[1].set_title(labels[1], fontsize=12, fontweight='bold')
    plt.colorbar(im2, ax=axes[1])
    
    # Add values
    for i in range(shape[0]):
        for j in range(shape[1]):
            state = i * shape[1] + j
            axes[1].text(j, i, f'{V2[state]:.3f}',
                        ha="center", va="center", color="w", fontsize=9)
    
    # Plot difference
    diff = V1 - V2
    grid_diff = diff.reshape(shape)
    im3 = axes[2].imshow(grid_diff, cmap='RdBu', interpolation='nearest',
                        vmin=-np.max(np.abs(diff)), vmax=np.max(np.abs(diff)))
    axes[2].set_title('Difference (Method 1 - Method 2)', fontsize=12, fontweight='bold')
    plt.colorbar(im3, ax=axes[2])
    
    # Add values
    for i in range(shape[0]):
        for j in range(shape[1]):
            state = i * shape[1] + j
            axes[2].text(j, i, f'{diff[state]:.3f}',
                        ha="center", va="center", color="black", fontsize=9)
    
    plt.tight_layout()
    plt.show()


# ===== Random Walk Helper Functions =====

def generate_random_walk_episode(start_state=2, num_states=5):
    """
    Generate one episode of the random walk MRP.
    
    Args:
        start_state: Starting state (default: 2 = center state C)
        num_states: Number of non-terminal states (default: 5 for A-E)
    
    Returns:
        episode_states: List of states visited
        episode_rewards: List of rewards received
    """
    episode_states = []
    episode_rewards = []
    
    state = start_state
    episode_states.append(state)
    
    while True:
        # Move left or right with equal probability
        if np.random.rand() < 0.5:
            next_state = state - 1  # Move left
        else:
            next_state = state + 1  # Move right
        
        # Check for terminal states
        if next_state < 0:  # Terminal left
            reward = 0
            episode_rewards.append(reward)
            break
        elif next_state >= num_states:  # Terminal right
            reward = 1
            episode_rewards.append(reward)
            break
        else:
            reward = 0
            episode_rewards.append(reward)
            state = next_state
            episode_states.append(state)
    
    return episode_states, episode_rewards


def random_walk_dp_solution(num_states=5, theta=1e-10):
    """
    Solve Random Walk value function using Dynamic Programming.
    
    Args:
        num_states: Number of non-terminal states
        theta: Convergence threshold
    
    Returns:
        V_dp: Exact value function
        iterations: Number of iterations to converge
    """
    V_dp = np.zeros(num_states)
    iteration = 0
    
    while True:
        delta = 0
        V_old = V_dp.copy()
        
        for s in range(num_states):
            # Expected value: 0.5 * V(s-1) + 0.5 * V(s+1)
            if s == 0:  # State A
                V_new = 0.5 * 0 + 0.5 * V_dp[s + 1]  # Left terminal = 0
            elif s == num_states - 1:  # State E
                V_new = 0.5 * V_dp[s - 1] + 0.5 * 1  # Right terminal = 1
            else:
                V_new = 0.5 * V_dp[s - 1] + 0.5 * V_dp[s + 1]
            
            V_dp[s] = V_new
            delta = max(delta, abs(V_old[s] - V_dp[s]))
        
        iteration += 1
        if delta < theta:
            break
    
    return V_dp, iteration


def plot_random_walk_results(avg_rms_td, avg_rms_mc, V_dp, V_td_final, V_mc_final, 
                             true_values, alpha, num_episodes, states=['A', 'B', 'C', 'D', 'E']):
    """
    Create comprehensive visualization of Random Walk results.
    
    Args:
        avg_rms_td: Average RMS error over episodes for TD
        avg_rms_mc: Average RMS error over episodes for MC
        V_dp: DP solution values
        V_td_final: Final TD values
        V_mc_final: Final MC values
        true_values: True value function
        alpha: Learning rate used
        num_episodes: Number of episodes
        states: State labels
    """
    fig = plt.figure(figsize=(16, 5))
    
    # Plot 1: Learning curves
    ax1 = plt.subplot(1, 3, 1)
    plt.plot(avg_rms_td, 'b-', label='TD(0)', linewidth=2.5, alpha=0.8)
    plt.plot(avg_rms_mc, 'r-', label='Monte Carlo', linewidth=2.5, alpha=0.8)
    plt.xlabel('Episodes', fontsize=11, fontweight='bold')
    plt.ylabel('RMS Error', fontsize=11, fontweight='bold')
    plt.title(f'Learning Curves (α={alpha})', fontsize=12, fontweight='bold')
    plt.legend(fontsize=10, loc='upper right')
    plt.grid(True, alpha=0.3)
    
    # Add shaded regions showing TD advantage
    episodes = np.arange(len(avg_rms_td))
    plt.fill_between(episodes, avg_rms_td, avg_rms_mc, 
                     where=(avg_rms_mc > avg_rms_td), 
                     alpha=0.2, color='green', 
                     label='TD advantage')
    
    # Plot 2: Final value estimates
    ax2 = plt.subplot(1, 3, 2)
    x = np.arange(len(states))
    width = 0.2
    
    plt.bar(x - 1.5*width, true_values, width, label='True Values', 
            color='black', alpha=0.7, edgecolor='black', linewidth=1.5)
    plt.bar(x - 0.5*width, V_dp, width, label='DP (exact)', 
            color='blue', alpha=0.6, edgecolor='blue', linewidth=1.5)
    plt.bar(x + 0.5*width, V_td_final, width, label='TD(0)', 
            color='green', alpha=0.6, edgecolor='green', linewidth=1.5)
    plt.bar(x + 1.5*width, V_mc_final, width, label='MC', 
            color='red', alpha=0.6, edgecolor='red', linewidth=1.5)
    
    plt.xlabel('State', fontsize=11, fontweight='bold')
    plt.ylabel('Value', fontsize=11, fontweight='bold')
    plt.title(f'Value Estimates after {num_episodes} Episodes', fontsize=12, fontweight='bold')
    plt.xticks(x, states, fontsize=10)
    plt.legend(fontsize=9, loc='upper left')
    plt.grid(True, alpha=0.3, axis='y')
    plt.ylim([0, 1])
    
    # Plot 3: Errors by state
    ax3 = plt.subplot(1, 3, 3)
    error_td = np.abs(V_td_final - true_values)
    error_mc = np.abs(V_mc_final - true_values)
    error_dp = np.abs(V_dp - true_values)
    
    x_pos = np.arange(len(states))
    plt.plot(x_pos, error_dp, 'bs-', label='DP error', linewidth=2, markersize=8, alpha=0.7)
    plt.plot(x_pos, error_td, 'g^-', label='TD(0) error', linewidth=2, markersize=8, alpha=0.7)
    plt.plot(x_pos, error_mc, 'r*-', label='MC error', linewidth=2, markersize=10, alpha=0.7)
    
    plt.xlabel('State', fontsize=11, fontweight='bold')
    plt.ylabel('Absolute Error', fontsize=11, fontweight='bold')
    plt.title('Error by State', fontsize=12, fontweight='bold')
    plt.xticks(x_pos, states, fontsize=10)
    plt.legend(fontsize=9, loc='upper left')
    plt.grid(True, alpha=0.3)
    plt.yscale('log')
    
    plt.tight_layout()
    plt.show()


def print_random_walk_summary(V_dp, V_td_final, V_mc_final, true_values, 
                              avg_rms_td, avg_rms_mc, dp_iterations, 
                              num_episodes, num_runs, alpha):
    """
    Print concise summary of Random Walk experiment results.
    """
    print("\n" + "="*70)
    print("Random Walk: DP, TD(0), and Monte Carlo Comparison")
    print("="*70)
    
    print("\nDP Solution:")
    print(f"  Converged in {dp_iterations} iterations")
    print(f"  Values: {V_dp}")
    
    print(f"\nTD(0) (α={alpha}, {num_episodes} episodes, {num_runs} runs):")
    print(f"  Final RMS error: {avg_rms_td[-1]:.4f}")
    print(f"  Values: {V_td_final}")
    
    print(f"\nMonte Carlo (α={alpha}, {num_episodes} episodes, {num_runs} runs):")
    print(f"  Final RMS error: {avg_rms_mc[-1]:.4f}")
    print(f"  Values: {V_mc_final}")
    
    print("\n" + "="*70)
    print(f"Result: TD(0) achieves {avg_rms_td[-1]:.4f} RMS error vs MC {avg_rms_mc[-1]:.4f}")
    print("="*70 + "\n")


def plot_q_values_frozen_lake(Q, title="Q-values", episode=0, grid_shape=(4, 4)):
    """
    Visualize Q-values for FrozenLake with arrows showing action values.
    
    Args:
        Q: Q-value array of shape (num_states, num_actions)
        title: Plot title
        episode: Current episode number
        grid_shape: Grid dimensions (rows, cols)
    """
    from IPython.display import display, clear_output
    
    clear_output(wait=True)
    
    fig, ax = plt.subplots(figsize=(12, 10))
    
    # FrozenLake 4x4 layout
    frozen_lake_layout = [
        ['S', 'F', 'F', 'F'],
        ['F', 'H', 'F', 'H'], 
        ['F', 'F', 'F', 'H'],
        ['H', 'F', 'F', 'G']
    ]
    
    # Action mapping: 0=Left, 1=Down, 2=Right, 3=Up
    action_names = ['←', '↓', '→', '↑']
    action_offsets = [
        (-0.25, 0),    # Left
        (0, -0.25),    # Down
        (0.25, 0),     # Right
        (0, 0.25)      # Up
    ]
    
    rows, cols = grid_shape
    
    # Draw grid
    for i in range(rows):
        for j in range(cols):
            state = i * cols + j
            cell_type = frozen_lake_layout[i][j]
            
            # Cell background
            if cell_type == 'S':
                color = 'lightblue'
                edgecolor = 'blue'
            elif cell_type == 'H':
                color = 'black'
                edgecolor = 'darkred'
            elif cell_type == 'G':
                color = 'gold'
                edgecolor = 'darkgreen'
            else:
                color = 'white'
                edgecolor = 'gray'
            
            rect = patches.Rectangle((j, rows - 1 - i), 1, 1, 
                                     linewidth=2, edgecolor=edgecolor, 
                                     facecolor=color, alpha=0.3)
            ax.add_patch(rect)
            
            # Add state label
            ax.text(j + 0.1, rows - i - 0.1, f's{state}', 
                   fontsize=8, color='gray', ha='left', va='top')
            
            # Add cell type label
            if cell_type == 'S':
                ax.text(j + 0.5, rows - i - 0.5, 'S', 
                       fontsize=16, color='blue', ha='center', va='center', 
                       fontweight='bold')
            elif cell_type == 'H':
                ax.text(j + 0.5, rows - i - 0.5, 'H', 
                       fontsize=16, color='red', ha='center', va='center', 
                       fontweight='bold')
            elif cell_type == 'G':
                ax.text(j + 0.5, rows - i - 0.5, 'G', 
                       fontsize=16, color='darkgreen', ha='center', va='center', 
                       fontweight='bold')
            
            # Skip Q-value arrows for terminal states
            if cell_type in ['H', 'G']:
                continue
            
            # Draw Q-values as arrows with values
            for action in range(4):
                q_val = Q[state, action]
                dx, dy = action_offsets[action]
                arrow_name = action_names[action]
                
                # Color based on Q-value (best action in green)
                best_action = np.argmax(Q[state])
                if action == best_action:
                    text_color = 'green'
                    fontweight = 'bold'
                else:
                    text_color = 'black'
                    fontweight = 'normal'
                
                # Position text
                text_x = j + 0.5 + dx
                text_y = rows - i - 0.5 + dy
                
                ax.text(text_x, text_y, f'{arrow_name}\n{q_val:.2f}', 
                       fontsize=9, color=text_color, ha='center', va='center',
                       fontweight=fontweight)
    
    ax.set_xlim(0, cols)
    ax.set_ylim(0, rows)
    ax.set_aspect('equal')
    ax.axis('off')
    ax.set_title(f'{title} (Episode {episode})', fontsize=14, fontweight='bold', pad=20)
    
    # Add legend
    legend_text = "Best action in green | S=Start, H=Hole, G=Goal"
    ax.text(cols/2, -0.3, legend_text, ha='center', fontsize=10, style='italic')
    
    display(fig)
    plt.close(fig)


def plot_cliff_walking_learning_curves(returns_sarsa, returns_qlearning, window=10):
    """
    Plot learning curves comparing SARSA and Q-Learning on Cliff Walking.
    
    Args:
        returns_sarsa: List of episode returns for SARSA
        returns_qlearning: List of episode returns for Q-Learning
        window: Window size for smoothing
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # Smooth the curves
    sarsa_smooth = np.convolve(returns_sarsa, np.ones(window)/window, mode='valid')
    qlearning_smooth = np.convolve(returns_qlearning, np.ones(window)/window, mode='valid')
    
    ax.plot(sarsa_smooth, label='SARSA (safe path)', color='blue', alpha=0.7, linewidth=2)
    ax.plot(qlearning_smooth, label='Q-Learning (optimal path)', color='red', alpha=0.7, linewidth=2)
    ax.set_xlabel('Episode', fontsize=12)
    ax.set_ylabel(f'Return (smoothed over {window} episodes)', fontsize=12)
    ax.set_title('Cliff Walking: SARSA vs Q-Learning Learning Curves', fontsize=14, fontweight='bold')
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()


def visualize_cliff_walking_policy(Q, title='Cliff Walking Greedy Policy'):
    """
    Visualize the greedy policy derived from Q-values on the cliff walking grid.
    Shows π(s) = argmax_a Q(s,a) for each state.
    
    Args:
        Q: Q-table (num_states x num_actions)
        title: Plot title
    """
    fig, ax = plt.subplots(figsize=(12, 4))
    
    grid_shape = (4, 12)
    num_actions = Q.shape[1]
    policy_grid = np.zeros(grid_shape, dtype=str)
    arrows = {0: '↑', 1: '→', 2: '↓', 3: '←'}
    
    # Extract greedy policy: π(s) = argmax_a Q(s,a)
    for state in range(Q.shape[0]):
        row = state // 12
        col = state % 12
        action = np.argmax(Q[state])  # Greedy action
        policy_grid[row, col] = arrows[action]
    
    # Mark special cells
    policy_grid[3, 0] = 'S'  # Start
    policy_grid[3, 11] = 'G'  # Goal
    for col in range(1, 11):
        policy_grid[3, col] = 'C'  # Cliff
    
    ax.imshow(np.ones(grid_shape), cmap='gray', alpha=0.3)
    
    for i in range(grid_shape[0]):
        for j in range(grid_shape[1]):
            if policy_grid[i, j] == 'S':
                ax.text(j, i, policy_grid[i, j], ha='center', va='center', 
                       fontsize=18, fontweight='bold', color='green')
            elif policy_grid[i, j] == 'G':
                ax.text(j, i, policy_grid[i, j], ha='center', va='center', 
                       fontsize=18, fontweight='bold', color='blue')
            elif policy_grid[i, j] == 'C':
                ax.add_patch(plt.Rectangle((j-0.5, i-0.5), 1, 1, 
                                          fill=True, color='red', alpha=0.5))
                ax.text(j, i, policy_grid[i, j], ha='center', va='center', 
                       fontsize=12, color='white', fontweight='bold')
            else:
                ax.text(j, i, policy_grid[i, j], ha='center', va='center', 
                       fontsize=16)
    
    ax.set_xlim(-0.5, grid_shape[1]-0.5)
    ax.set_ylim(grid_shape[0]-0.5, -0.5)
    ax.set_xticks(range(grid_shape[1]))
    ax.set_yticks(range(grid_shape[0]))
    ax.grid(True)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_aspect('equal')
    
    plt.tight_layout()
    plt.show()


def render_cliff_walking_episode(env, Q, epsilon, max_steps=100, render_delay=0.3):
    """
    Render a single episode following the current policy.
    
    Args:
        env: Gymnasium environment (with render_mode set during creation)
        Q: Q-table
        epsilon: Exploration rate
        max_steps: Maximum steps per episode
        render_delay: Delay between steps in seconds
    
    Returns:
        total_reward: Episode return
        steps: Number of steps taken
    """
    state, _ = env.reset()
    total_reward = 0
    steps = 0
    done = False
    
    print("\nRendering episode...")
    time.sleep(0.5)
    
    while not done and steps < max_steps:
        # Epsilon-greedy action selection
        if np.random.rand() < epsilon:
            action = env.action_space.sample()
        else:
            action = np.argmax(Q[state])
        
        state, reward, done, truncated, _ = env.step(action)
        total_reward += reward
        steps += 1
        
        # Add delay to see the movement
        time.sleep(render_delay)
        
        if truncated:
            done = True
    
    # Keep window open a bit longer to see final state
    time.sleep(1.0)
    
    print(f"Episode finished: Return = {total_reward}, Steps = {steps}")
    return total_reward, steps
